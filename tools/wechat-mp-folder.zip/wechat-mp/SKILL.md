---
name: wechat-mp
description: 微信公众号文章纯 HTTP 抓取工具。通过伪装微信手机客户端 User-Agent，直接用 urllib 抓取 mp.weixin.qq.com 文章正文，零浏览器依赖、零第三方库依赖。当用户发送 mp.weixin.qq.com/s/xxx 链接、需要抓取/解析/读取微信公众号文章内容时触发。
---

# 微信文章纯 HTTP 读取（wechat-mp）

## 概述

通过伪装微信手机客户端 UA，直接用 urllib 抓取微信公众号文章正文，**零浏览器依赖，零第三方库依赖**。仅依赖 Python 3 标准库。

## 核心原理

微信对 `User-Agent: MicroMessenger/xxx` 的请求直接返回完整 HTML，无需 JS 渲染。用 urllib 带上微信手机 UA 即可绕过验证墙，避开 Playwright/Selenium/Headless Chrome 等重方案。

## 触发场景

- 用户发送 `https://mp.weixin.qq.com/s/xxxxx` 格式链接
- 用户说"读这篇公众号文章"/"抓这篇微信文章"/"解析这个公众号链接"
- 用户提供 .skill 或 zip 安装包要求安装本工具

## 文件说明

```
wechat-mp/
├── SKILL.md       # 本文档
├── wechat_mp.py   # 主程序（urllib + re + json，标准库）
├── summary.sh     # 命令行入口包装（python3 wechat_mp.py "$1"）
└── install.sh     # 一键安装到 ~/.openclaw/skills/wechat-mp/
```

## 使用方式

### 方式 1：命令行

```bash
/usr/bin/python3 ~/.openclaw/skills/wechat-mp/wechat_mp.py "<文章链接>"
```

### 方式 2：包装脚本

```bash
bash ~/.openclaw/skills/wechat-mp/summary.sh "<文章链接>"
```

### 方式 3：直接发链接给 Domi

发送 `https://mp.weixin.qq.com/s/xxxxx`，自动调用。

## 输出格式（JSON）

```json
{
  "code": 0,
  "msg": "解析成功",
  "data": {
    "title": "文章标题",
    "author": "公众号名称",
    "publish_time": "发布时间",
    "content": "正文内容（纯文本）",
    "content_length": 字符数
  }
}
```

**错误码**：

| code | 含义 |
|------|------|
| 0 | 解析成功 |
| -1 | 非法链接（非 mp.weixin.qq.com） |
| -2 | 网络请求失败 |
| -3 | 正文提取失败（需登录/付费/被风控） |

## 限制与边界

- ❌ **不能读取登录可见 / 付费文章**（缺 Cookie，需浏览器登录态）
- ⚠️ **频率过高会触发风控**，建议间隔 ≥ 1 秒
- ⚠️ **同一 IP 大量请求可能被封**，批量采集需配合代理池
- ⚠️ 仅支持已公开、未被删除的文章
- ✅ 支持所有未加密的微信公众号文章正文

## 安装方式

### 方式 A：从 .skill 包安装（OpenClaw 标准）

```bash
# 解压到 OpenClaw skills 目录即可生效
unzip wechat-mp.skill -d ~/.openclaw/skills/
# 或：openclaw skills install wechat-mp.skill
```

### 方式 B：从便携 zip 安装（任意 Linux/macOS）

```bash
unzip wechat-mp-portable.zip
cd wechat-mp/
bash install.sh   # 自动装到 ~/.openclaw/skills/wechat-mp/
```

### 方式 C：手动复制

```bash
mkdir -p ~/.openclaw/skills/wechat-mp
cp wechat_mp.py summary.sh SKILL.md ~/.openclaw/skills/wechat-mp/
```

## 依赖

- **Python 3.6+**（仅使用 `urllib` / `ssl` / `re` / `json` / `sys` 标准库）
- **零外部依赖**（无需 requests / bs4 / lxml / playwright）

## 验证结果（2026-06-09）

- ✅ 标题 / 作者 / 正文均正确提取（4020 字符样本）
- ✅ 无需系统库依赖
- ✅ 无需 Playwright / 浏览器
- ✅ 单次请求 < 3 秒

## 重命名记录

- 2026-06-21：`wechat_mp_simple` → `wechat-mp`（去下划线+加连字符、去掉 `_simple` 后缀，保留核心语义）