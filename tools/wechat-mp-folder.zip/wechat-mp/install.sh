#!/bin/bash
# wechat-mp 一键安装脚本
# 把本目录文件安装到 ~/.openclaw/skills/wechat-mp/
# 用法: bash install.sh

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="$HOME/.openclaw/skills/wechat-mp"

echo "=========================================="
echo "  wechat-mp 安装脚本 v1.0"
echo "=========================================="
echo "源目录: $SCRIPT_DIR"
echo "目标目录: $TARGET_DIR"
echo ""

# 检查 Python 3
if ! command -v python3 &> /dev/null; then
    echo "❌ 错误：未检测到 python3，请先安装 Python 3.6+"
    exit 1
fi

PY_VERSION=$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])')
echo "✅ 检测到 Python $PY_VERSION"

# 创建目标目录
mkdir -p "$TARGET_DIR"

# 拷贝核心文件（不递归拷贝 install.sh 自身）
for f in SKILL.md wechat_mp.py summary.sh; do
    if [ -f "$SCRIPT_DIR/$f" ]; then
        cp "$SCRIPT_DIR/$f" "$TARGET_DIR/"
        echo "✅ 已复制: $f"
    else
        echo "⚠️  跳过: $f (源文件不存在)"
    fi
done

# 设置可执行权限
chmod +x "$TARGET_DIR/wechat_mp.py" 2>/dev/null || true
chmod +x "$TARGET_DIR/summary.sh" 2>/dev/null || true

echo ""
echo "=========================================="
echo "  ✅ 安装完成！"
echo "=========================================="
echo ""
echo "使用方式："
echo "  /usr/bin/python3 $TARGET_DIR/wechat_mp.py \"<微信文章URL>\""
echo ""
echo "  或："
echo ""
echo "  bash $TARGET_DIR/summary.sh \"<微信文章URL>\""
echo ""
echo "验证安装（测试一个微信文章链接）："
echo "  bash $TARGET_DIR/summary.sh \"https://mp.weixin.qq.com/s/LDdj3BvbZUJIiShibQuHlg\""
echo ""