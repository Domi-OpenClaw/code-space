#!/bin/bash
# 微信文章读取命令行入口
# 用法: bash summary.sh <url>
#
# 路径自适应：
#   - 若脚本在 ~/.openclaw/skills/wechat-mp/ 下，直接用同目录的 wechat_mp.py
#   - 否则回退到 ~/.openclaw/skills/wechat-mp/wechat_mp.py
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "$SCRIPT_DIR/wechat_mp.py" ]; then
    python3 "$SCRIPT_DIR/wechat_mp.py" "$1"
else
    python3 ~/.openclaw/skills/wechat-mp/wechat_mp.py "$1"
fi