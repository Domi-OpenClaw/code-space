#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
微信公众号文章纯HTTP抓取器 v1.2（零依赖版）
直接用 urllib + re，不依赖任何第三方库
"""
import sys
import re
import json
import ssl
import urllib.request

# 微信手机客户端 UA（核心关键）
WECHAT_UA = (
    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) "
    "AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 "
    "MicroMessenger/8.0.34(0x16082222) NetType/WIFI Language/zh_CN"
)

MP_REGEX = re.compile(r"https?://mp\.weixin\.qq\.com/s/[\w]+")


def add_scene(url):
    if "scene=1" not in url:
        url = url + ("&scene=1" if "?" in url else "?scene=1")
    return url


def extract_js_content(html):
    """按标签层级提取 js_content div 内部文本"""
    start = html.find('id="js_content"')
    if start == -1:
        start = html.find("id='js_content'")
    if start == -1:
        return ''
    # 跳过 <div id="js_content" ... >
    p = html.find('>', start)
    depth = 1
    i = p + 1
    while i < len(html) and depth > 0:
        if html[i:i+5] == '<div ':
            depth += 1
        elif html[i:i+6] == '</div>':
            depth -= 1
            if depth == 0:
                return html[p+1:i]
        i += 1
    return html[p+1:i]


def extract_content(html):
    """从微信文章 HTML 中提取标题、作者、发布时间、正文"""
    # 标题：<h1 class="rich_media_title " id="activity-name">
    m = re.search(r'<h1[^>]*rich_media_title[^>]*id=["\']activity-name["\'][^>]*>(.*?)</h1>', html, re.DOTALL)
    if not m:
        m = re.search(r'<h1[^>]*rich_media_title[^>]*>(.*?)</h1>', html, re.DOTALL)
    title = re.sub(r'<[^>]+>', '', m.group(1)).strip() if m else "无标题"

    # 作者：在 meta_content 里找第一个 rich_media_meta_text
    m = re.search(r'id=["\']meta_content["\'][^>]*>(.*?)</div>', html, re.DOTALL)
    if m:
        author_m = re.search(r'rich_media_meta_text[^>]*>(.*?)</span>', m.group(1), re.DOTALL)
        author = re.sub(r'<[^>]+>', '', author_m.group(1)).strip() if author_m else "未知作者"
    else:
        author = "未知作者"

    # 发布时间
    pub_time = "未知时间"
    m = re.search(r'<span[^>]*id=["\']publish_time["\'][^>]*>(.*?)</span>', html, re.DOTALL)
    if not m:
        m = re.search(r'<em[^>]*id=["\']publish_time["\'][^>]*>(.*?)</em>', html, re.DOTALL)
    if m:
        pub_time = re.sub(r'<[^>]+>', '', m.group(1)).strip()

    # 正文
    raw = extract_js_content(html)
    text = re.sub(r'<[^>]+>', '', raw)
    text = re.sub(r'&\w+;', ' ', text)
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    content = '\n'.join(lines)

    return {
        "title": title,
        "author": author,
        "publish_time": pub_time,
        "content": content,
        "content_length": len(content),
    }


def fetch_wechat_article(url):
    """抓取微信文章"""
    if not MP_REGEX.match(url):
        return {"code": -1, "msg": "非法链接，请输入 mp.weixin.qq.com 链接"}

    url = add_scene(url)

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    req = urllib.request.Request(url, headers={"User-Agent": WECHAT_UA})
    try:
        with urllib.request.urlopen(req, timeout=20, context=ctx) as resp:
            html = resp.read().decode("utf-8", errors="replace")
    except Exception as e:
        return {"code": -2, "msg": f"请求失败：{str(e)}"}

    data = extract_content(html)

    if not data["content"] or len(data["content"]) < 100:
        return {
            "code": -3,
            "msg": "正文提取失败，可能需要登录或文章受限",
            "data": data,
        }

    return {"code": 0, "msg": "解析成功", "data": data}


if __name__ == "__main__":
    url = sys.argv[1] if len(sys.argv) > 1 else ""
    if not url:
        print(json.dumps({"code": -1, "msg": "请提供文章链接"}, ensure_ascii=False))
        sys.exit(1)

    result = fetch_wechat_article(url)
    print(json.dumps(result, ensure_ascii=False, indent=2))
